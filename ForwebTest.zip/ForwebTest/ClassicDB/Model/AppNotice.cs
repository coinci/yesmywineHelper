﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassicDB.Model
{
    public class AppNotice
    {
        public decimal Notice_ID { get; set; }

        public string Notice_Owner { get; set; }

        public string Notice_Email { get; set; }

        public string Notice_Topic { get; set; }

        public string Notice_Text { get; set; }

        public DateTime Begin_Date { get; set; }

        public DateTime End_Date { get; set; }


    }
}
