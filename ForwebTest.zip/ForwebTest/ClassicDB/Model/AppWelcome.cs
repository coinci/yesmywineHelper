﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassicDB.Model
{
    public class AppWelcome
    {
        public string Wel_Msg { get; set; }

        public decimal Msg_Seq { get; set; }
    }
}
