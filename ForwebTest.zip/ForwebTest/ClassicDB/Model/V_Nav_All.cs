﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassicDB.Model
{
    public class V_Nav_All
    {
        public decimal Display_Seq { get; set; }

        public string Space_Code { get; set; }

        public string Space_Desc { get; set; }

        public string Page_Name { get; set; }

        public string Display { get; set; }

        public string Description { get; set; }

    }
}
