﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ClassicDB;
using ClassicDB.Model;

namespace ForwebTest.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public JsonResult GetLeftNav()
        {
            //Get nav list base on user need to filter
            List<V_Nav_All> navList = new List<V_Nav_All>();
            navList.Add(new V_Nav_All() { Display_Seq = 1, Space_Code = "DB", Space_Desc = "Business DashBoard", Page_Name = "", Display = "", Description = "" });
            navList.Add(new V_Nav_All() { Display_Seq = 5, Space_Code = "AL", Space_Desc = "Business Pre-Alerting", Page_Name = "", Display = "", Description = "" });
            navList.Add(new V_Nav_All() { Display_Seq = 10, Space_Code = "CSR", Space_Desc = "Customer services", Page_Name = "ordinq", Display = "Order Inquiry", Description = "Sals Order inquiry" });
            navList.Add(new V_Nav_All() { Display_Seq = 10, Space_Code = "CSR", Space_Desc = "Customer services", Page_Name = "qkord", Display = "Quick Order Entry", Description = "Offering the easy and quick order entry for CSR" });
            navList.Add(new V_Nav_All() { Display_Seq = 20, Space_Code = "MAT", Space_Desc = "Materials & Planning", Page_Name = "", Display = "", Description = "" });
            navList.Add(new V_Nav_All() { Display_Seq = 30, Space_Code = "LOG", Space_Desc = "Logistic", Page_Name = "", Display = "", Description = "" });
            navList.Add(new V_Nav_All() { Display_Seq = 40, Space_Code = "TC", Space_Desc = "Trade management (TC)", Page_Name = "", Display = "", Description = "" });
            navList.Add(new V_Nav_All() { Display_Seq = 50, Space_Code = "MD", Space_Desc = "Master data", Page_Name = "", Display = "", Description = "" });
            navList.Add(new V_Nav_All() { Display_Seq = 60, Space_Code = "FIN", Space_Desc = "Finance & Accounting", Page_Name = "", Display = "", Description = "" });
            navList.Add(new V_Nav_All() { Display_Seq = 70, Space_Code = "COMM", Space_Desc = "Common inquiries", Page_Name = "invinq", Display = "Inventory Inquiry", Description = "public Role for Inventory Inquiry" });
            navList.Add(new V_Nav_All() { Display_Seq = 80, Space_Code = "Help", Space_Desc = "Help", Page_Name = "manual", Display = "User Manuals", Description = "For All users (End User Manuals)" });
            navList.Add(new V_Nav_All() { Display_Seq = 90, Space_Code = "system administration", Space_Desc = "usermnt", Page_Name = "usrmnt", Display = "User management", Description = "Admin Only for user maint" });
            navList.Add(new V_Nav_All() { Display_Seq = 90, Space_Code = "system administration", Space_Desc = "syspra", Page_Name = "syspra", Display = "System Parameters", Description = "Admin Only for system Parameters Setup" });


            //Const have 2 level tree deep
            List<TreeNode> nodeList = new List<TreeNode>();
            for (int i = 0; i < navList.Count; )
            {
                TreeNode tn = new TreeNode();
                tn.text = navList[i].Space_Desc;
                tn.selectable = true;
                nodeList.Add(tn);
                if (i + 1 < navList.Count && navList[i + 1].Display_Seq == navList[i].Display_Seq)
                {
                    tn.nodes = new List<TreeNode>();
                    int offset = 0;
                    while (true)
                    {

                        TreeNode childNode = new TreeNode();
                        childNode.text = navList[i + offset].Display;
                        childNode.selectable = true;
                        tn.nodes.Add(childNode);
                        offset++;
                        if ((i + offset) >= navList.Count || navList[i + offset].Display_Seq != navList[i].Display_Seq)
                            break;
                    }
                    i = i + offset;
                }
                else
                    i++;
            }

            return Json(nodeList);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}